from django.apps import AppConfig


class MedishebaConfig(AppConfig):
    name = 'MediSheba'
