from django.apps import AppConfig


class StaticConfig(AppConfig):
    name = 'static'
